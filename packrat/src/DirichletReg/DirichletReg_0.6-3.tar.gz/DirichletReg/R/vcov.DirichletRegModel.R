vcov.DirichletRegModel <- function(object, ...){
  object$vcov
}
