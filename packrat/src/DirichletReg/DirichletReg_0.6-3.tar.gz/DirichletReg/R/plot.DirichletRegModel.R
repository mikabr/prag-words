plot.DirichletRegModel <- function(){

### residuals ~ fitted (line at y = 0)

### theoretical quantiles vs. std. residuals   QQ-plot of residuals. half-normal of abs-values?

### scale-location   sqrt(std. resid) ~ fitted

### std. residuals vs. leverage

}
